package elso_bead;

public class Deltafa extends Plant{
    
    public Deltafa(String name, int nutrition)
    {
        super(name, nutrition);
    }
    /*
    @Override
    public void addNutrition() {
        if(Radiation.getRadiation().equals(Radiation.DELTA)){
            this.nutrition += 4;
        }       
    }
    
    @Override
    public void decreaseNutrition() {
        if(Radiation.getRadiation().equals(Radiation.NEUTRAL)){
            this.nutrition -= 1;
        }
        if(Radiation.getRadiation().equals(Radiation.ALFA)){
            this.nutrition -= 3;
        }
    }*/
    
    @Override
    public void manageNutrition() {
        if(Radiation.getRadiation().equals(Radiation.DELTA)){
            this.nutrition += 4;
        }       
        if(Radiation.getRadiation().equals(Radiation.NEUTRAL)){
            this.nutrition -= 1;
        }
        if(Radiation.getRadiation().equals(Radiation.ALFA)){
            this.nutrition -= 3;
        }       
    }
    
    @Override
    public boolean isAlive(){
        if(this.getNutrition() < 1){
            this.setAlive(false);
        }else{
            this.setAlive(true);
        }
        return this.getAlive();
    }


    
    @Override
    public void sendRequest(){
        if(this.getNutrition() < 5){
            Radiation.getDeltaRequests(4);
        }
        if(this.getNutrition() >= 5 && this.getNutrition() <= 10){
            Radiation.getDeltaRequests(1);
        }
    }
    
}

    

