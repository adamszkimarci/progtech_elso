package elso_bead;


public enum Radiation {
    
    ALFA, DELTA, NEUTRAL;
    
    protected static int requests;
    protected static int requestsOverall;
    
    
    public static Radiation getRadiation(){
        if(requestsOverall > 3){
            return Radiation.ALFA;
        }
        if(requestsOverall < -3){
            return Radiation.DELTA;
        }else{
            return Radiation.NEUTRAL;
        }
    }
    
    public static void getAlfaRequests(int value){
        Radiation.requests += value;
    }
    
    public static void getDeltaRequests(int value){
        Radiation.requests -= value;
    }
}
