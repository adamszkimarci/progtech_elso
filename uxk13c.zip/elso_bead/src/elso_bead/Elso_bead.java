package elso_bead;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.List;
import java.util.NoSuchElementException;

public class Elso_bead {

    private static Plant noveny(String sor) {
        StringTokenizer st = new StringTokenizer(sor);
        String name = st.nextToken();
        Plant.Faj faj = Plant.Faj.valueOf(st.nextToken());
        int nutrition = Integer.parseInt(st.nextToken());

        switch(faj){
            case a:
                return new Puffancs(name, nutrition);
            case d:
                return new Deltafa(name, nutrition);
            case p:
                return new Parabokor(name, nutrition);
            default:
                return null;
        }
    }
    
    public static void main(String[] args) throws IOException {
        List<Plant> plants = new ArrayList<>();
        
        if (args.length != 1) {
            System.err.println("ERROR: pontosan egy paramétert várok,");
            System.exit(1);
        }
        try{
            Scanner sc = new Scanner(new File(args[0]));
        
            int numberOfPlants = Integer.parseInt(sc.nextLine());
        
            for(int i = 0; i < numberOfPlants; i++){
            plants.add(noveny(sc.nextLine()));
            }
        
            int days = Integer.parseInt(sc.nextLine());
        
            for(int i = 0; i < days; ++i){
                for(Plant p : plants){
                    if(p.isAlive()){
                        p.simulateDay();
                    }
                }
                //Egy másik megoldás, hogy mindennap 0-ról indul újra a
                //"requests"
                Radiation.requestsOverall = Radiation.requests;
                //Radiation.requests = 0;
            }
        }catch(NoSuchElementException e){
            System.err.println("Üres a file!");
        }
        
        for(Plant p : plants){
            if(p.isAlive()){
                System.out.println(p.getName() + " túlélte.");
            }else{
                System.out.println(p.getName() + " nem élte túl.");
            }
        }
        
        
    }
    
}
