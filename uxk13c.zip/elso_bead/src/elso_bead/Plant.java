package elso_bead;

public abstract class Plant {
    private final String name;
    protected int nutrition;
    private boolean alive;
    
    public Plant(String name, int nutrition)
    {
        this.name = name;
        this.nutrition = nutrition;
        this.alive = true;
    }
    
    public enum Faj{ a, d, p }

    public String getName() {
        return name;
    }

    public int getNutrition() {
        return nutrition;
    }
    
    public boolean getAlive(){
        return alive;
    }
    
    public void setAlive(boolean value){
        this.alive = value;
    }
    
    public abstract boolean isAlive();
    /*
    public abstract void addNutrition();
    
    public abstract void decreaseNutrition();
    */
    public abstract void manageNutrition();
    
    public abstract void sendRequest();
    
    public void simulateDay(){
        if(this.isAlive()){
            this.manageNutrition();
            /*this.addNutrition();
            this.decreaseNutrition();*/
            this.sendRequest();
        }
    }
}
